Component({
    externalClasses: ['icon-class'],

    properties: {
        // small || large || default
        size: {
            type: Number,
            value: 20
        },
        src: {
            type: String,
            value: ''
        }
    }
});
