#pragma once
#include "TIMCloud.h"
#include "json.h"


// 用于测试API接口
void TestApi();
