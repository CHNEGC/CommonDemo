# 跨平台库 （Windows）

## 下载地址

[最新C接口下载](https://imsdk-1252463788.cos.ap-guangzhou.myqcloud.com/4.8.10/cross-platform/TIM_Cross_Platform_Windows_latest.zip)

## TIMSDK for Windows

[集成SDK](https://cloud.tencent.com/document/product/269/33489)

[概述](https://cloud.tencent.com/document/product/269/33490)
