# 跨平台库 （iOS）

## 下载地址

[最新C接口下载](https://imsdk-1252463788.cos.ap-guangzhou.myqcloud.com/4.8.10/cross-platform/TIM_Cross_Platform_iOS_latest.zip)

