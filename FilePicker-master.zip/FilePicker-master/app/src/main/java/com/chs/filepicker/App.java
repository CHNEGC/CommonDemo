package com.chs.filepicker;

import android.app.Application;

/**
 * 作者：chs on 2017-08-25 17:24
 * 邮箱：657083984@qq.com
 */

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
