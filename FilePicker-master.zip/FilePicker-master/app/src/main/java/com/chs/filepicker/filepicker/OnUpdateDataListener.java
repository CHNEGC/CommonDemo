package com.chs.filepicker.filepicker;

/**
 * 作者：chs on 2017-08-25 10:39
 * 邮箱：657083984@qq.com
 */

public interface OnUpdateDataListener {
    void update(long size);
}
