package com.chs.filepicker.filepicker.adapter;

/**
 * 作者：chs on 2017-09-06 14:57
 * 邮箱：657083984@qq.com
 */

public interface OnDeleteListener {
    void delete(int position);
}
