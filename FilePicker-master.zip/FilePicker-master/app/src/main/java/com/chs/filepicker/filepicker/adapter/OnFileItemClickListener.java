package com.chs.filepicker.filepicker.adapter;

/**
 * 作者：chs on 2017-08-25 10:15
 * 邮箱：657083984@qq.com
 * 条目点击
 */

public interface OnFileItemClickListener {
    void click(int position);
}
