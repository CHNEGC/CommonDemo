### v2.5
    * Add storage selection button

### v2.4
    * Minor fixes
    * Add method start for Fragment

### v2.3
    * Minor fixes
    * Add method setHideHiddenFilesEnabled()

### v2.2
    * Minor fixes
    * Add Slovak translation (thanks to pylerSM)

### v2.1
	* Use Glide to load thumbnails
	* Add method setUseFirstItemAsUpEnabled()

### v2.0
	* Refactoring
	* Add runtime permissions support
	* Update icons and design
	* Now using support library

### v1.8
	* Migrate to Android Studio

### v1.7
	* Added optional quit button with ENABLE_QUIT_BUTTON option
	* When user getting back to previous directory, list automatically scrolled to previous position

### v1.6
	* Changed icons select_all and invert_selection 
	* All strings resources in the library get efp__ prefix

### v1.5
	* Added "Sort" button and two options: SET_SORT_TYPE and DISABLE_SORT_BUTTON 

### v1.4
	* SET_FILTER_BY_EXTENSION is deprecated and removed. Use SET_FILTER_EXCLUDE or SET_FILTER_LISTED instead.
	* In library added translations to Ukranian, Spanish, Hindi, Arabic, Eesti, Lettish, German and Japanese. Sample application not translated.
	* Added light theme (ExFilePickerThemeLight). Dark theme renamed to ExFilePickerThemeDark.

### v1.3
    * Removed ActionBarSherlock dependency
    * Added "New folder" button and DISABLE_NEW_FOLDER_BUTTON option

### v1.2
    * Asynchronous thumbnails loading
    * Changed loading icon
    
### v1.1
	* Catch some exceptions
    * Added SET_START_DIRECTORY option
