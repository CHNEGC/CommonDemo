package me.rosuh.filepicker.bean

/**
 *
 * @author rosu
 * @date 2018/11/21
 */
interface FileBean {
    var fileName: String
    var filePath: String
    var beanSubscriber: BeanSubscriber
}